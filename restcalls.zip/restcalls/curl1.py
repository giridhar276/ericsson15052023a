import shlex
import subprocess
import json

cmd = 'curl -i https://api.github.com'
args = shlex.split(cmd)
print(args)
process = subprocess.Popen(args, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = process.communicate()

print("Output :",stdout.decode('utf-8'))
print(stderr)

#reader = json.load(stdout.decode('utf-8'))

#print(reader)
