
import getpass    
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"    # change this to your username

print("checking ", url, "using user:", user)

local_file = "notes.txt"   # provide some filename which is existing in local dir
with open(local_file,"r") as fh:
    mydata = fh.read()
    
files = {
    "description": "rest api - giri testing - again",
    "public": "true",
    "user" : user,
    "files": {
    local_file: {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(user,'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'))
#print(r1.json())
data = json.loads(r1.text)
for key,value in data.items():
    print(key.ljust(30),value)