

import getopt, sys, os, errno  
import getpass    
import requests
import json
from requests.auth import HTTPBasicAuth

server = "https://api.github.com"
url = server + "/gists"
endpoint = "https://api.github.com/users/giridhar276/repo"

files = {
  "name": "Hello-World",
  "description": "This is your test repository",
  "homepage": "https://github.com",
  "private": False,
  "has_issues": True,
  "has_projects": True,
  "has_wiki": True,
    "files": {
    "githubtest0.py": {
    "content": "dummy"
        }
      }
}

r1 = requests.post(url, data=json.dumps(files), auth=HTTPBasicAuth('giridhar276','01067d842c5671f5bb98d6fb1b43ce84b95b9771'))



print(r1.text)
