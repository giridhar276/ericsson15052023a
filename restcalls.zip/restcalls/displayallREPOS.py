 
  
import requests
import json


server = "https://api.github.com"

endpoint = "/users/giridhar276/repos"

final = server + endpoint

r = requests.get(final, auth=('giridhar276',''))
print(r.text)

# r.text ------------> json format
# reading data from server and converting to dictionary from json


 