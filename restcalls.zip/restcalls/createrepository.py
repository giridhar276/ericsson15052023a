## display the current user repositories in github

from github import Github

# First create a Github instance:

# using username and password

g = Github("giridhar276@gmail.com","2934dfe9ab555681eef4b7e41e2fac313607eb75")

user = g.get_user()

print(user)
repo = user.create_repo("boa")

print(repo) 
